// It is a Glue B/w View and Model
/* Controller , Take Input from the View (UI) 
and Give it to the Model, Model gives output to 
the controller and controller will write output to the 
view.
*/
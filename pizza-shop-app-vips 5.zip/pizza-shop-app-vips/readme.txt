PLAN
1. Add to Cart Functionality
a) Attach an Event on Add to Cart Button, e.g click event and when user 
click on add to cart button then it will call a addtocart function.
the solution is use addEventListener

b) All Pizza has add to Cart and it is calling the addtoCart function.
Now the question arise which button is clicked? I mean which pizza 
addtocart is happen
the solution is using this keyword, because this contains the current
calling object reference, so we get current calling button reference.

c) the problem with this we get only the current button, but how i come 
to know which pizza it is ?
During printing of pizza , attach the pizza id with button.
if i get pizza id so i can search pizza id in the pizza array, so i get 
pizza object. once i get pizza object i can mark true in isAddedInCart

d) Now print those pizzas whose isAddedInCart flag is true. Print in 
the Basket section. Print (DOM)



// console.log('Hello Node JS');
// function add(x,y){
//     return x + y;
// }
// console.log(add(10,20));
const fs = require('fs'); // Common JS 
console.log('Code Start...');
const p = '/Users/amitsrivastava/Documents/online-coding-ide-rec/day-3/04-WritingCode.mp4';
const stream = fs.createReadStream(p,{highWaterMark:200});
stream.on('open',()=>{
    console.log('Stream Open');
})
stream.on('data', chunk=>{
    console.log('Chunk is ', chunk);
});
stream.on('end',()=>{
    console.log('Stream ends');
});
stream.on('close',()=>{
    console.log('Stream Close')
})
// fs.readFile(p,(err, content)=>{
//     if(err){
//         console.log('Error is ', err);
//     }
//     else{
//         console.log('File Content is ', content);
//     }
// }); // Async

console.log('Code Ends');
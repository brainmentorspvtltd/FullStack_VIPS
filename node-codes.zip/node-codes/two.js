const fs = require('fs');
const p = '/Users/amitsrivastava/Documents/online-code-platform/node-codes';
// fs.watchFile(p,()=>{
//     console.log('File Change...');
// });
fs.watch(p,(x,y)=>{
    console.log('File Change...' , x, y);
});
console.log('Prg Start');
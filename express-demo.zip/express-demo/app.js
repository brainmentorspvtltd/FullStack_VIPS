import express, { request } from 'express';
import { userRoutes } from './routes/user-routes.js';
const app=express();
app.use('/',userRoutes);
// app.use('/',ideRoutes);
//404 middelware
app.use((request,response,next)=>{
    response.json({message:'Invalid UrL'});
})
const server=app.listen(1234,(err)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log('Server up and running');
    }

})
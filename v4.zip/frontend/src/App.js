import logo from './logo.svg';
import './App.css';
import { QuestionPage } from './modules/ide/pages/QuestionPage';
import { AllQuestions } from './modules/questions/pages/AllQuestions';

function App() {
  return (
   <AllQuestions/>
  );
}

export default App;

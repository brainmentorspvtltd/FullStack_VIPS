import React from 'react'
import Editor from '@monaco-editor/react';
import {useRef} from 'react';
import Button from '@mui/material/Button';
import { apiclient } from '../../../shared/services/api-client';
// https://dontpad.com/vips-code
export const Ide = () => {
  const editorRef = useRef(null); // Hook

  const mountIt = (ref)=>{
    editorRef.current = ref;

  }
  const getCode = async ()=>{
    const sourceCode = editorRef.current.getValue();
    const obj = {'code':sourceCode};
    try{
    const response = await apiclient.post(process.env.REACT_APP_CODE_TEST,obj);
    console.log('Response is ', response.data.code);
    }
    catch(err){
      console.log('Code Fail , Send to Server ', err);
    }
    //console.log('Code ... ', editorRef.current.getValue());
  }
    const skeleton = `class Solution{
      public int logic(int x){
        return x;
      }
    }`;
  return (
    <>
    <Editor
        onMount={mountIt}
        height="70vh"
        defaultLanguage="java"
        defaultValue={skeleton}
        
      />
      <Button onClick={getCode} variant="contained">Submit</Button>
    </>
  )
}

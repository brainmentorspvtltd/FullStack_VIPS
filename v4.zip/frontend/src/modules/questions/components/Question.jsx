import React from 'react'

export const Question = () => {
  return (
    <div>Question</div>
  )
}

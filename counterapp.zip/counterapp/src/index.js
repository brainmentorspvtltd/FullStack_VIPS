/*
It is a Bridge File B/w App.js (Root Component) 
and index.html (Page)
App.js will give VDOM
and index.js has ReactDOM , ReactDOM convert VDOM into DOM.

*/
import ReactDOM from 'react-dom';
import App from './App';
const div = document.querySelector('#root');
const root = ReactDOM.createRoot(div);
root.render(<App/>); // Calling App Component in JSX Style <App/>

import React from "react";
import { Greet } from "./components/Greet";

/*
It is Root/First Component
Component - It is just a small view.
Component Name Start with Capital Letter
Component - Best Practice Arrow Function
Bottom Line - Component is a Function at the end
Component contains JSX
JSX - JavaScript and XML. JSX Object Oriented
JSX is similar 99% (HTML)
*/
const App = ()=>{
  const name = 'Amit';
  const myStyle = {color:'red', backgroundColor:'cyan'};
  
  return (<div>
    {name==='Amit'?<p>Welcome {name}</p>:<p>Hello {name}</p>}
    {/* <h1 style={myStyle}>Welcome {name}</h1> */}
    <h2>Hi React JS {Date.now()}</h2>
    <Greet myname = {name}/>
  </div>)
  //return (<h1>Hello React JS</h1>)
  // document.createElement('h1'); // DOM
 // return React.createElement('h1', null, 'Hello React JS'), React.createElement('h2', null, 'Hi React JS');
// return React.createElement('div', null,  React.createElement('h1', null, 'Hello React JS'), React.createElement('h2', null, 'Hi React JS'))
}
export default App;
// this is a root component / first component
// component is just a function which returns JSX.
//React Suggests use Arrow Function for Building Component
const App = ()=>{
  return (<h1>Hello React JS</h1>);
}
export default App;
export const Greet = ({myname})=>{
    const sayGreet = ()=>{
        const today = new Date(); // TimeStamp
        const hours = today.getHours();
        if(hours>=4 && hours<12){
            // return <p>Good Morning {props.myname}</p>
            return <p>Good Morning {myname}</p>
        }
        else if(hours>=12 && hours<16){
            return <p>Good Afternoon {myname}</p>
        }
        else if(hours>=16 && hours<19){
            return <p>Good Evening {myname}</p>
        }
        else if(hours>=19 && hours<4){
            return <p>Good Night {myname}</p>
        }

    }
    return (<>
        {sayGreet()}
    </>);
}
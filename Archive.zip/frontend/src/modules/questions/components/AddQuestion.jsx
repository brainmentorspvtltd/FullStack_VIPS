import React, { useRef, useState } from 'react'
import TextField from '@mui/material/TextField';
import Container from '@mui/material/Container';
import { TextareaAutosize } from '@mui/base/TextareaAutosize';
import { Button } from '@mui/material';
import { apiclient } from '../../../shared/services/api-client';
export const AddQuestion = () => {
    const [message, setMessage] =  useState('');
    const name = useRef();
    const desc = useRef();
    const code =useRef();
    const testcases = useRef();
    const addQuestion = async ()=>{
        const questionObject = {
            'name': name.current.value,
            'desc':desc.current.value,
            'skeletoncode':code.current.value,
            'testcases':testcases.current.value
        }
        console.log('Question Object is ', questionObject);
        const response = await apiclient.post('http://localhost:1234/add-question', questionObject);
        console.log('Response is ', response);
        setMessage(response.data.message);
    }
  return (
    <Container>
        <h2>{message}</h2>
        <label>name</label>
        <TextField inputRef = {name} id="q-name" label="Name" variant="filled" />
        <br/>
        <label>Desc</label>
        <TextareaAutosize ref = {desc} />
        <br/>
        <label>Code Skeleton</label>
        <TextareaAutosize ref = {code} />
        <br/>
        <label>Test Cases</label>
        <TextareaAutosize ref = {testcases} />
        <Button onClick={addQuestion} variant="contained">Add New Question</Button>


    </Container>
  )
}

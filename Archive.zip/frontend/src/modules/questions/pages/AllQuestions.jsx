import React, { useEffect, useState } from 'react'
import { apiclient } from '../../../shared/services/api-client';

export const AllQuestions = () => {
  const [questions, setQuestions] = useState([]);
    const getAllQuestions = async ()=>{
        const response = await apiclient.get(process.env.REACT_APP_ALLQUESTIONS);
         
        setQuestions(response.data.records);
        console.log('All Questions are ', questions);
    }
    useEffect(()=>{
        getAllQuestions();
        // [] - Component Mount
        // no [] - Component Update
        // [] + function return - Component UnMount
    },[]) ; // Life Cycle Hook
  return (
      <>
        {questions.length==0 && <p>No Questions</p>}
        {questions.length>0 && questions.map(question=>{
          return (<div>
            <p>Name : {question.name}</p>
            <p>Desc : {question.desc}</p>
            </div>)
        })}
      </>
  )
}

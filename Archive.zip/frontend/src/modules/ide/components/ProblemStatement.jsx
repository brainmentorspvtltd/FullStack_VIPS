import { Typography } from '@mui/material'
import React from 'react'

export const ProblemStatement = ({question}) => {
  console.log('PS ', question );
  return (
    <>
    <Typography>
        {question.name}
    </Typography>
   
    <Typography>
    {question.desc}
    </Typography>
    </>
  )
}

import React, { useEffect, useState } from 'react'
import { ProblemStatement } from '../components/ProblemStatement'
import { Ide } from '../components/Ide'
import { Header } from '../../../shared/components/Header'
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import { apiclient } from '../../../shared/services/api-client';
export const QuestionPage = () => {
  const [question, setQuestion] = useState({});
  const getSingleQuestion = async ()=>{
   const response = await  apiclient.get('http://localhost:1234/singlequestion/64e33385e9b8248fe14f66b6');
   
   setQuestion(response.data.question); 
  }
  useEffect(()=>{
    getSingleQuestion();
  },[]);
  return (
    <Container>
        <Header/>
        <Grid container spacing={2}>
            <Grid item xs={6}>
            <ProblemStatement question = {question}/>
            </Grid>
            <Grid item xs={6}>
            <Ide question = {question}/>
            </Grid>
        </Grid>
        </Container>
  )
}

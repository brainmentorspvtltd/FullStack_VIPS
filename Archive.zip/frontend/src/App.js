import logo from './logo.svg';
import './App.css';
import { QuestionPage } from './modules/ide/pages/QuestionPage';
import { AllQuestions } from './modules/questions/pages/AllQuestions';
import { AddQuestion } from './modules/questions/components/AddQuestion';

function App() {
  return (
    <QuestionPage/>
  );
}

export default App;

import { QuestionModel } from "../models/question-schema.js";

export const questionController = {
    async addQuestion(request, response){
        //console.log('Data Rec ', request.body);
        const questionObject = request.body;
        try{
        const doc = await QuestionModel.create(questionObject);
        response.json({message:'Question Added', 'record':doc});
        }
        catch(err){
            console.log('Error During Question Add ', err);
            response.json({message:'Error During Add Question'});
        }
    },
    updateQuestion(request, response){
        response.json({message:'Question Updated'});
    },
    removeQuestion(request, response){
        response.json({message:'Question Removed'});
    },
    async allQuestions(request, response){
        try{
        const docs = await QuestionModel.find({}).exec();
        response.json({message:'All Records ', records: docs});
        }
        catch(err){
            console.log('Error in Questions ', err);
            response.json({message:'Error in Questions '});
        }
        
    }
}
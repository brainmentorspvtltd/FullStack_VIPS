import logo from './logo.svg';
import './App.css';
import Bmi from './Page/bmi';

function App() {
  return (
    <Bmi />
  );
}

export default App;

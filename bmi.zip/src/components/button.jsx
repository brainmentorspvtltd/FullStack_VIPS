import React from 'react';

const Button = ({val,classname,calculate}) => {
    return (
        <button onClick={()=>{calculate(val)}} className={classname}>
            {val}
        </button>
    );
}

export default Button;

import React, { useEffect } from "react";
import { useState } from "react";

const Display = ({ bmi }) => {
  const [statement, setStatement] = useState("");
  const [color, setcolor] = useState("");
  useEffect(() => {
    if (bmi < 16) {
      setStatement("Severe Thinness");
      setcolor("red");
    } else if ((bmi) => 16 && bmi < 17) {
      setStatement("Moderate Thinness");
      setcolor("red");
    } else if (bmi >= 17 && bmi < 18.5) {
      setStatement("Mild Thinness");
      setcolor("red");
    } else if (bmi >= 18.5 && bmi < 25) {
      setStatement("Normal");
      setcolor("green");
    } else if (bmi >= 25 && bmi < 30) {
      setStatement("Overweight");
      setcolor("red");
    } else {
      setStatement("Obese Class");
      setcolor("red");
    }
  }, [bmi]);

  return (
    <>
      {/* BMI */}
      <span>{bmi}  {bmi?<span> kg/m<sup>2</sup> </span>:""}  </span>
      {bmi ? ( 
        <span style={{ backgroundColor: `${color}` }}>{statement}</span>
      ) : (
        ""
      )}
    </>
  );
};

export default Display;

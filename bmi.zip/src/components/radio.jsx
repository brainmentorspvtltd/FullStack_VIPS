import React from 'react';

const Radio = ({gender}) => {
    return (
       <>&nbsp;
        <input type="radio"    name="gender"  id={gender} value={gender}/>
        &nbsp; <label htmlFor={gender}>{gender}</label>
       </>
    );
}

export default Radio;

import React from 'react';

const Textfield = ({type,placeholder,id,takeInput}) => {
    return (
       <input   onChange={takeInput}  type={type}  placeholder={placeholder}    id={id}  />
    );
}

export default Textfield;

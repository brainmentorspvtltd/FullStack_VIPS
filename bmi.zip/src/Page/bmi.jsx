import React, { useState } from "react";
import Textfield from "../components/textfield";
import Radio from "../components/radio";
import Button from "../components/button";
import Display from "../components/display";

const Bmi = () => {
  const [bmi, setBmi] = useState("");
  const obj = { age: "", weight: "", height: "" };
  const takeInput = (event) => {
    if (event.target.getAttribute("id") === "age") obj.age = event.target.value;
    else if (event.target.getAttribute("id") === "height")
      obj.height = event.target.value;
    else obj.weight = event.target.value;
  };

  const calculate = (val) => {
    console.log(val);
    if (val === "Calculate") {
      if (obj.height === "" || obj.age === "" || obj.weight === "")
        return alert("Enter all details!!!");
      let hei = obj.height / 100;
      let result = obj.weight / (hei * hei);
      result = result.toFixed(2);
      setBmi(result);
    } else if (val === "Clear") {
      window.location.reload();
    }
  };
const style={position:"absolute",left:"280px"}
  return (
    <div style={style} className="container">
      <table className="mt-5">
        <tr>
          <td>BMI is:</td>
          <td>
            <Display bmi={bmi} />
          </td>
        </tr>
        <tr>
          <td>
            <label htmlFor="age">Age:</label>
          </td>
          <td>
            <Textfield
              takeInput={takeInput}
              type="number"
              placeholder="Enter your age"
              id="age"
            />
          </td>
        </tr>
        <tr>
          <td>
            <label htmlFor="">Gender:</label>
          </td>
          <td>
            <Radio gender="male" />
            <Radio gender="female" />
          </td>
        </tr>
        <tr>
          <td>
            <label htmlFor="height">Height:</label>
          </td>
          <td>
            <Textfield
              takeInput={takeInput}
              id="height"
              type="number"
              placeholder="Enter your Height in cm"
            />
          </td>
        </tr>
        <tr>
          <td>
            <label htmlFor="weight">Weight:</label>
          </td>
          <td>
            <Textfield
              takeInput={takeInput}
              id="weight"
              type="number"
              placeholder="Enter your weight in kg"
            />
          </td>
        </tr>
        <tr>
          <td>
            <Button
              calculate={calculate}
              classname="btn btn-success"
              val="Calculate"
            />
          </td>
          <td>
            <Button
              calculate={calculate}
              classname="btn btn-danger"
              val="Clear"
            />
          </td>
        </tr>
      </table>
    </div>
  );
};

export default Bmi;

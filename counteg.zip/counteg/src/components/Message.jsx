export const Message = (props)=>{
    return (<h1 className={props.classname}>
        {props.value} {props.countValue}</h1>)
}
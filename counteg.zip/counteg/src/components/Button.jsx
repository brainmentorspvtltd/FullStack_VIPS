import React from 'react'

export const Button = (props) => {
    
    const clicked = ()=>{
        
        props.fn(props.value);
        console.log("Clicked Happen...", props.value);
    }
  return (
    <button onClick={clicked} className ={props.classname}>{props.value}</button>
  )
}

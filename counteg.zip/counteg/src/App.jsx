import React from "react";
import { CounterPage } from "./pages/CounterPage";


/*
It is Root/First Component
Component - It is just a small view.
Component Name Start with Capital Letter
Component - Best Practice Arrow Function
Bottom Line - Component is a Function at the end
Component contains JSX
JSX - JavaScript and XML. JSX Object Oriented
JSX is similar 99% (HTML)
*/
const App = ()=>{
  return (<CounterPage/>);
}
export default App;
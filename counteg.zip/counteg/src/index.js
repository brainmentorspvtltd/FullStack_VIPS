/*
Bridge File b/w index.html and App.js
index.html - DOM
App.js - VDOM 
JSX Build VDOM
VDOM Map to DOM By Using ReactDOM
*/
// Picking a div from index.html
import ReactDOM from 'react-dom/client';
import App from './App';
const div = document.querySelector('#root'); // DOM
const root = ReactDOM.createRoot(div);
root.render(<App/>); // VDOM Render into DOM
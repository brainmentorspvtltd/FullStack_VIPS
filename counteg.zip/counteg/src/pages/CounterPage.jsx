import { useState } from 'react';
import { Button } from '../components/Button';
import {Message} from '../components/Message';
export const CounterPage = ()=>{
    console.log('Count Page Call');
    const [count, setCount] = useState(0);
    //let count = 0;
    const updateCount= (value)=>{
        if(value ==='+'){
            setCount(count + 1);
       // count++;
        }
        else{
            setCount(count - 1);
           // count--;
        }
        console.log('Update Count ', count);
    }
    return (<div className = 'container'>
        <Message classname="alert alert-info text-center" value = "Counter App"/>
        <Message classname="alert alert-success" value = "Counter is " countValue ={count}/>
        <Button fn = {updateCount} classname="btn btn-success me-2" value = "+"/>
        <Button fn = {updateCount} classname="btn btn-danger" value = "-"/>
    </div>)
}
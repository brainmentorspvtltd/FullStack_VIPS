import { SchemaTypes } from "mongoose";
import mongoose from "../connection.js";
const schema = mongoose.Schema;
const userSchema = new schema({
  name: { type: SchemaTypes.String, required: true },
  email: { type: SchemaTypes.String, required: true },
  password: { type: SchemaTypes.String, required: true },
  mobile: { type: SchemaTypes.String, required: true },
});
export const userModel = mongoose.model("users", userSchema);

import mongoose from "mongoose";
const URL="mongodb+srv://admin1234:admin1234@cluster0.on6ibpz.mongodb.net/userdb?retryWrites=true&w=majority"
const promise= mongoose.connect(URL);
promise.then(()=>{
  console.log("Connection created successfully!!!");
}).catch((e)=>{
    console.log("DB connection failed!!!");
});
export default mongoose;

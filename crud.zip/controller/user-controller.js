import { userModel } from "../db/models/user-model.js";

export const userController = {
  profile(req, res) {
    const userName = req.params.username;
    const age = req.params.age;
    res.json({ msg: userName + age });
  },
  login(req, res) {
    res.json({ msg: "login" });
  },
  register(req, res) {
    res.json({ msg: "register" });
  },
  async create(req, res) {
    const info = req.body;
    try {
      const document = await userModel.create(info);
      if (document && document._id) {
        res.json({ msg: "your document is saved" });
      } else {
        res.json({ msg: "your document is not saved" });
      }
    } catch (e) {
      res.json({ msg: "network error!!!" });
    }
  },
  async read(req, res) {
    // const documents=  await userModel.find({}).exec();
    const document =await userModel.findOne({"email":"xyz@gmail.com"})
    res.json({documents:document})
  },
  async update(req, res) {
 const info =req.body;
//  console.log(info) 
const document =await userModel.findOneAndUpdate({"name":info.name},{$set:{"email":"XYZ@gmail.com"}},{new:true})
     res.json({document:document})
// console.log(req.body)

  },
 async delete(req, res) {
      const info = req.body;
    const doc= await userModel.findOneAndDelete({"name":info.name})
     res.json({doc:doc})
  },
};

import express from "express";
import { userController } from "../controller/user-controller.js";
const userRoutes= express.Router();
// userRoutes.get("?",userController.profile);
userRoutes.post("/login",userController.login);
userRoutes.post("/register",userController.register);
userRoutes.post("/create",userController.create);
userRoutes.get("/read",userController.read);
userRoutes.put("/update",userController.update);
userRoutes.delete("/delete",userController.delete);





export default userRoutes;
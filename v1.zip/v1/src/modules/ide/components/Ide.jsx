import React from 'react'
import Editor from '@monaco-editor/react';
import {useRef} from 'react';
import Button from '@mui/material/Button';
// https://dontpad.com/vips-code
export const Ide = () => {
    const editorRef = useRef(null);

  function handleEditorDidMount(editor, monaco) {
    editorRef.current = editor; // Now Editor Reference store in Refs
  }
  return (
    <>
    <Editor

        height="70vh"
        defaultLanguage="java"
        defaultValue="// some comment"
        onMount={handleEditorDidMount}
      />
      <Button variant="contained">Submit</Button>
    </>
  )
}

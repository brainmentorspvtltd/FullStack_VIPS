export const Second=()=>{
    return (<h1>Hi I am Second Component</h1>)
}
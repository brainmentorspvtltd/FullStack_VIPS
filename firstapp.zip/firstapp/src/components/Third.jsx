export const Third=()=>{
    const fruits=["orange","Mango","Apple","Banana"];
    const products=[{id:1001,name:'Margherita',url:'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/margherita.90f9451fd66871fb6f9cf7d506053f18.1.jpg?width=375'},{id:1002,name:'corn N cheese',url:'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/corn.f8baa08ad7f607f1de30f96bb9245b50.1.jpg?width=375'}]
    // return (<h1>Hi I am Third Component</h1>)
    return (<>
    <h1>Hii I am third component</h1>
    <div>
    {/* {fruits.map((fruit,index)=>{
        return <h1 key={index}>{fruit}Fruit</h1>
    })} */}
    {products.map((product)=><div key={product.id}>
        <img src={product.url} alt={product.name}/>
        <p>Id {product.id} Name {product.name} </p>
    </div>)}
    </div>
    </>)
}
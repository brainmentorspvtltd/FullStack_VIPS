// export const First=(props)
export const First=({msg})=>{
    return (<h1>Hi {msg} I am First Component</h1>)
}
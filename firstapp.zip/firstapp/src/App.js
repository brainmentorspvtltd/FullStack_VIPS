import React from 'react';

import { First } from './components/First';
import { Second } from './components/Second';
import { Third } from './components/Third';
const App=()=>{
const value=3;
const conditionalRendering=()=>{
    if(value===1){
        return <First  msg="Hello"/>
    }
   else if(value===2){
        return <Second/>
    }
    else if(value===3){
        return <Third/>
    }
    else{
       return (<h1>Nothing returns</h1>) 
    }
}
const myStyle={
    backgroundColor:'red',
};
const myName='Anjali';
    return (<>
    
    {conditionalRendering()}
    <h1 style={myStyle}> Hii React  {myName}</h1>
    </>);

}

export default App;
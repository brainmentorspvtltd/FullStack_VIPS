//import logo from './logo.svg';
import './App.css';
import { Counter } from './pages/counterpage';


function App() {
  return (<>
  <Counter/>
  </>
);
}

export default App;

// It is a Glue B/w View and Model
/* Controller , Take Input from the View (UI) 
and Give it to the Model, Model gives output to 
the controller and controller will write output to the 
view.
*/

import productOperations from "../services/product-operations.js";

async function showProducts(){
    const products = await productOperations.readAllProducts();
    console.log('All Products are ', products);
}
showProducts();
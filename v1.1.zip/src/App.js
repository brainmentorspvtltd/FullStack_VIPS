import logo from './logo.svg';
import './App.css';
import { QuestionPage } from './modules/ide/pages/QuestionPage';
import Questions from './modules/questions/Questions';
import Paths from './routes/Paths';

function App() {
  return (
    <Paths />
  );
}

export default App;

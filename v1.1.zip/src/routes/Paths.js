import React from "react";
import { Routes, Route } from "react-router-dom";
import Questions from "../modules/questions/Questions";
import { QuestionPage } from "../modules/ide/pages/QuestionPage";

const Paths = () => {
  return (
    <Routes>
      <Route  path="/" element={<div>Hello I am Main Component</div>} />
      <Route path="/problems" element={<Questions />} />
      <Route path="/problems/:desc" element={<QuestionPage />} />
    </Routes>
  );
};


export default Paths;

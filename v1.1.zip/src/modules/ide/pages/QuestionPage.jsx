import React from "react";
import { ProblemStatement } from "../components/ProblemStatement";
import { Ide } from "../components/Ide";
import { Header } from "../../../shared/components/Header";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";
import { useParams } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";
export const QuestionPage = () => {
  const { desc } = useParams();
  const [data,setdata]= useState(null)
  const [flag, setFlag] = useState(false);
  useEffect(() => {
    let json = JSON.parse(localStorage.getItem("json"));
    const isFound = json.find(
      (e) => e.title.toLowerCase().replace(/ /g, "-") === desc
    );
    isFound ? setFlag(true) : setFlag(false);
    isFound?setdata(isFound):setdata(null)
  }, []);
  return (
    <>
      {flag ? (
        <Container>
          <Header />
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <ProblemStatement data={data} />
            </Grid>
            <Grid item xs={6}>
              <Ide />
            </Grid>
          </Grid>
        </Container>
      ) : (
        <div>There is no problem defined!!!</div>
      )}
    </>
  );
};

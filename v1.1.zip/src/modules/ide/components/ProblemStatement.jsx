import { Typography } from "@mui/material";
import React from "react";

export const ProblemStatement = ({ data }) => {
  console.log("data is", data);

  return (
    <>
      <Typography>
        <p style={{ fontWeight: "600", fontSize: "21px" }}>{data.title}</p>
        <p style={{fontSize:"15px"}}>
          {data.difficultylevel}
        </p>
      </Typography>
      <Typography>{data.desc}</Typography>
      <Typography></Typography>
      <Typography>
        <p style={{ fontWeight: "600" }}>Example 1: </p>
        <pre
          style={{
            backgroundColor: "#000a2008",
            padding: "5px 10px",
            borderRadius: "7px",
          }}
        >
          {data.example["one"]}
        </pre>
        <p style={{ fontWeight: "600" }}>Example 2: </p>
        <pre
          style={{
            backgroundColor: "#000a2008",
            padding: "5px 10px",
            borderRadius: "7px",
          }}
        >
          {data.example["two"]}
        </pre>
      </Typography>
    </>
  );
};
